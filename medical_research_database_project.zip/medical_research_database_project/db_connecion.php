<?php
// Database connection file

$servername = "localhost"; // Change if your database is hosted elsewhere
$username = "root"; // Default username for local MySQL server
$password = ""; // Default password for local MySQL server, replace if set
$dbname = "clinical_research"; // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Connection successful
// echo "Connected successfully"; // Uncomment for debugging
?>