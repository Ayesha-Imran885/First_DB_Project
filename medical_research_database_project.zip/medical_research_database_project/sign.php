<?php
// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection details
    $servername = "localhost"; // Database server
    $username = "root"; // Database username
    $password = ""; // Database password
    $dbname = "ayesha"; // Database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO user (user_type, email, username, password) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $user_type, $email, $username, $hashed_password);

    // Set parameters and execute
    $user_type = $_POST['user_type'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password']; // Raw password input

    // Hash the password for security
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    if ($stmt->execute()) {
        echo "<div style='text-align: center; margin-top: 20px; font-size: 1.2em; color: green;'>Thank you, $user_type! You have signed in successfully with email: <strong>$email</strong> and username: <strong>$username</strong>.</div>";
    } else {
        echo "<div style='text-align: center; margin-top: 20px; font-size: 1.2em; color: red;'>Error: " . htmlspecialchars($stmt->error) . "</div>";
    }

    // Close connections
    $stmt->close();
    $conn->close();
}
?>
