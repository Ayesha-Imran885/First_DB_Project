<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Clinical Data</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #e3f2fd, #bbdefb);
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background: #fff;
            padding: 30px 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            width: 90%;
            max-width: 500px;
            text-align: center;
        }

        h1 {
            font-size: 2.2em;
            color: #1976d2;
            margin-bottom: 20px;
        }

        input {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 20px;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 1em;
            transition: border 0.3s;
        }

        input:focus {
            border-color: #1976d2;
            outline: none;
        }

        button {
            padding: 10px 20px;
            background: #1976d2;
            color: white;
            font-size: 1.2em;
            border: none;
            border-radius: 5px;
        }

        button:hover {
            background: #155a9f;
        }

        .footer {
            margin-top: 20px;
            font-size: 0.9em;
            color: #555;
        }
        
        table {
           width: 100%;
           margin-top: 20px; 
           border-collapse: collapse; 
        }
        
        th, td {
           border: 1px solid #ddd; 
           padding: 8px; 
           text-align: left; 
        }
        
        th {
           background-color: #f2f2f2; 
           color: black; 
        }
        
        .text-danger {
           color:red; 
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Search Clinical Data</h1>
        <form method="post">
           <input type="text" placeholder="Enter keywords..." name="search" required>
           <button type="submit" name="submit">Search</button>
        </form>

        <div class="container my-5">
            <table>
                <?php
                // Database connection details
                $servername = "localhost";
                $username = "root"; // Replace with your database username
                $password = ""; // Replace with your database password
                $dbname = "ayesha"; // Your database name

                // Create connection
                $con = new mysqli($servername, $username, $password, $dbname);

                // Check connection
                if ($con->connect_error) {
                    die("Connection failed: " . $con->connect_error);
                }

                // Initialize statement variables
                $stmt_user = null;
                $stmt_drugs = null;
                $stmt_researcher = null;
                $stmt_trials = null;

                if (isset($_POST['submit'])) {
                    $search = $_POST['search'];

                    // Prepare the SQL statements for different tables
                    $sql_user = "SELECT id, username, email FROM user WHERE email = ?";
                    $stmt_user = $con->prepare($sql_user);
                    if ($stmt_user) {
                        $stmt_user->bind_param("s", $search);
                    } else {
                        echo '<p class="text-danger">Error preparing user query.</p>';
                    }

                    $like_search = "%" . $search . "%";

                    $sql_drugs = "SELECT id, drug_name, description FROM drugs WHERE drug_name LIKE ? OR description LIKE ?";
                    $stmt_drugs = $con->prepare($sql_drugs);
                    if ($stmt_drugs) {
                        $stmt_drugs->bind_param("ss", $like_search, $like_search);
                    } else {
                        echo '<p class="text-danger">Error preparing drugs query.</p>';
                    }

                    $sql_researcher = "SELECT id, name, specialization FROM researcher WHERE name LIKE ? OR specialization LIKE ?";
                    $stmt_researcher = $con->prepare($sql_researcher);
                    if ($stmt_researcher) {
                        $stmt_researcher->bind_param("ss", $like_search, $like_search);
                    } else {
                        echo '<p class="text-danger">Error preparing researcher query.</p>';
                    }

                    $sql_trials = "SELECT id, title, description FROM clinical_trials WHERE title LIKE ? OR description LIKE ?";
                    $stmt_trials = $con->prepare($sql_trials);
                    if ($stmt_trials) {
                        $stmt_trials->bind_param("ss", $like_search, $like_search);
                    } else {
                        echo '<p class="text-danger">Error preparing trials query.</p>';
                    }

                    // Execute all statements and display results
                    if ($stmt_user && $stmt_user->execute()) {
                        // Get results for users
                        $result_user = $stmt_user->get_result();
                        if ($result_user->num_rows > 0) {
                            echo '<thead>
                                    <tr>
                                        <th>User ID</th>
                                        <th>Username</th>
                                        <th>Email</th>
                                    </tr>
                                  </thead>';
                            echo '<tbody>';
                            while ($row = $result_user->fetch_assoc()) {
                                echo '<tr>
                                        <td>' . htmlspecialchars($row['id']) . '</td>
                                        <td>' . htmlspecialchars($row['username']) . '</td>
                                        <td>' . htmlspecialchars($row['email']) . '</td>
                                      </tr>';
                            }
                            echo '</tbody>';
                        } else {
                            echo '<p class="text-danger">No users found.</p>';
                        }
                    }

                    if ($stmt_drugs && $stmt_drugs->execute()) {
                        // Get results for drugs
                        $result_drugs = $stmt_drugs->get_result();
                        if ($result_drugs->num_rows > 0) {
                            echo '<thead>
                                    <tr>
                                        <th>Drug Name</th>
                                        <th>Description</th>
                                    </tr>
                                  </thead>';
                            echo '<tbody>';
                            while ($row = $result_drugs->fetch_assoc()) {
                                echo '<tr>
                                        <td>' . htmlspecialchars($row['drug_name']) . '</td>
                                        <td>' . htmlspecialchars($row['description']) . '</td>
                                      </tr>';
                            }
                            echo '</tbody>';
                        } else {
                            echo '<p class="text-danger">No drugs found.</p>';
                        }
                    }

                    if ($stmt_researcher && $stmt_researcher->execute()) {
                        // Get results for researchers
                        $result_researcher = $stmt_researcher->get_result();
                        if ($result_researcher->num_rows > 0) {
                            echo '<thead>
                                    <tr>
                                        <th>Researcher Name</th>
                                        <th>Specialization</th>
                                    </tr>
                                  </thead>';
                            echo '<tbody>';
                            while ($row = $result_researcher->fetch_assoc()) {
                                echo '<tr>
                                        <td>' . htmlspecialchars($row['name']) . '</td>
                                        <td>' . htmlspecialchars($row['specialization']) . '</td>
                                      </tr>';
                            }
                            echo '</tbody>';
                        } else {
                            echo '<p class="text-danger">No researchers found.</p>';
                        }
                    }

                    if ($stmt_trials && $stmt_trials->execute()) {
                        // Get results for clinical trials
                        $result_trials = $stmt_trials->get_result();
                        if ($result_trials->num_rows > 0) {
                            echo '<thead>
                                    <tr>
                                        <th>Trial Title</th>
                                        <th>Description</th>
                                    </tr>
                                  </thead>';
                            echo '<tbody>';
                            while ($row = $result_trials->fetch_assoc()) {
                                echo '<tr>
                                        <td>' . htmlspecialchars($row['title']) . '</td>
                                        <td>' . htmlspecialchars($row['description']) . '</td>
                                      </tr>';
                            }
                            echo '</tbody>';
                        } else {
                            echo '<p class="text-danger">No clinical trials found.</p>';
                        }
                    }
                }

                // Close connections
                foreach ([$stmt_user, $stmt_drugs, $stmt_researcher, $stmt_trials] as &$stmt) { 
                   if ($stmt) { 
                       // Close the statement if it exists
                       $stmt->close(); 
                   } 
                }
                
                // Close the database connection
                if ($con) { 
                   // Close the connection if it exists
                   mysqli_close($con); 
                }
                ?>
                
            </table>
        </div>

        <div class="footer">
            <p>&copy; 2025 Clinical Research Portal. All Rights Reserved.</p>
        </div>
    </div>
</body>
</html>

